package BL;

/**
 *
 * @author franz
 */
public class Cart {
    private int articleid;
    private int amount;

    public Cart(int articleid, int amount) {
        this.articleid = articleid;
        this.amount = amount;
    }

    public int getArticleid() {
        return articleid;
    }

    public void setArticleid(int articleid) {
        this.articleid = articleid;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    
}
