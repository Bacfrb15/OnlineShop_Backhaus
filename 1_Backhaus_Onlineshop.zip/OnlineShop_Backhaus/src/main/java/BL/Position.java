package BL;

/**
 *
 * @author franz
 */
public class Position {
    private int articleid;
    private int orderid;
    private int amount;

    public Position(int articleid, int orderid, int amount) {
        this.articleid = articleid;
        this.orderid = orderid;
        this.amount = amount;
    }

    public int getArticleid() {
        return articleid;
    }

    public void setArticleid(int articleid) {
        this.articleid = articleid;
    }

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
